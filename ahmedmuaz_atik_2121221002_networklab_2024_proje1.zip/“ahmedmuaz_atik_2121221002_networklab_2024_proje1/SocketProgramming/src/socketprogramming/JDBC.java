package socketprogramming;

import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author ahmed
 */
public class JDBC {

    public static void main(String[] args) throws SQLException {

    }

    public static void insertUser(String u_name, String u_password) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        st.executeUpdate("INSERT INTO users (name, password) VALUES ('" + u_name + "', '" + u_password + "')");
        st.close();
    }

    public static void insertProjectMember(int project_id, int user_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        st.executeUpdate("INSERT INTO project_members (project_id, user_id, online) VALUES ('" + project_id + "', '" + user_id + "', 0)");
        st.close();
    }

    public static void insertProject(String project_name, String project_key, String project_owner) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_key FROM projects");

        boolean isExist = false;

        while (rs.next()) {
            if (rs.getString("project_key").equals(project_key)) {
                isExist = true;
            }
        }

        if (!isExist) {
            st.executeUpdate("INSERT INTO projects (project_name, project_key, project_owner) VALUES ('" + project_name + "', '" + project_key + "', '" + project_owner + "')");
        }

        st.close();
    }

    public static void insertMessages(int p_id, int s_id, String m) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        st.executeUpdate("INSERT INTO messages (project_id, sender_id, message) VALUES ('" + p_id + "', '" + s_id + "', '" + m + "')");
        st.close();
    }

    public static void updateRecent(String project_name, String user_name) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        st.executeUpdate("UPDATE recents SET project_name = '" + project_name + "', user_name = '" + user_name + "'");
        st.close();
    }
    
    public static String getNameFromRecent() throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT user_name FROM recents");
        
        String name = "";
        
        while (rs.next()) {
            name = rs.getString("user_name");
        }
        
        return name;
    }
    
    public static String getProjectFromRecent() throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_name FROM recents");
        
        String name = "";
        
        while (rs.next()) {
            name = rs.getString("project_name");
        }
        
        return name;
    }
    
    public static ArrayList<String> getProjectMessages(int project_id) throws SQLException {
        ArrayList<String> messages = new ArrayList<>();

        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, sender_id, message FROM messages");

        while (rs.next()) {
            if (rs.getInt("project_id") == project_id) {
                String msg = rs.getString("message");

                if (checkProjectOwner(getUserByID(rs.getInt("sender_id")), project_id)) {
                    messages.add(getUserByID(rs.getInt("sender_id")) + " (Owner): " + msg);
                } else {
                    messages.add(getUserByID(rs.getInt("sender_id")) + " (Member): " + msg);
                }

            }
        }

        return messages;
    }

    public static ArrayList<String> getProjectUsers(int project_id) throws SQLException {
        ArrayList<String> users = new ArrayList<>();

        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, user_id FROM project_members");

        while (rs.next()) {
            if (rs.getInt("project_id") == project_id) {
                users.add(getUserByID(rs.getInt("user_id")));
            }
        }

        return users;
    }

    public static boolean checkProjectMember(int project_id, int user_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, user_id FROM project_members");

        boolean isProjectMember = false;

        while (rs.next()) {
            if (rs.getInt("project_id") == project_id && rs.getInt("user_id") == user_id) {
                isProjectMember = true;
            }
        }

        return isProjectMember;
    }

    public static boolean checkProject(String key) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_key FROM projects");

        boolean isProject = false;

        while (rs.next()) {
            if (rs.getString("project_key").equals(key)) {
                isProject = true;
            }
        }

        return isProject;
    }

    public static boolean checkUser(String u_name) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT name FROM users");

        boolean isUser = false;

        while (rs.next()) {
            if (rs.getString("name").equals(u_name)) {
                isUser = true;
            }
        }

        st.close();

        return isUser;
    }

    public static boolean checkProjectOwner(String u_name, int project_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, project_owner FROM projects");

        boolean isOwner = false;

        while (rs.next()) {
            if (rs.getInt("project_id") == project_id) {
                if (rs.getString("project_owner").equals(u_name)) {
                    isOwner = true;
                }
            }
        }

        return isOwner;
    }

    public static boolean checkPassword(String u_password) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT password FROM users");

        boolean isPassword = false;

        while (rs.next()) {
            if (rs.getString("password").equals(u_password)) {
                isPassword = true;
            }
        }

        st.close();

        return isPassword;
    }

    public static String getUserByID(int id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT user_id, name FROM users");

        String projects = "";

        while (rs.next()) {
            if (rs.getInt("user_id") == id) {
                projects = rs.getString("name");
            }
        }

        return projects;
    }

    public static String getAllProjects(int user_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, user_id FROM project_members");

        String projects = "";

        while (rs.next()) {
            if (rs.getInt("user_id") == user_id) {
                projects += getProjectNameByID(rs.getInt("project_id")) + ",";
            }
        }

        return projects;
    }

    public static String getProjectNameByID(int project_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, project_name FROM projects");

        String name = "";

        while (rs.next()) {
            if (rs.getInt("project_id") == project_id) {
                name = rs.getString("project_name");
            }
        }

        return name;
    }

    public static String getProjectName(String key) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_key, project_name FROM projects");

        String name = "";

        while (rs.next()) {
            if (rs.getString("project_key").equals(key)) {
                name = rs.getString("project_name");
            }
        }

        return name;
    }

    public static String getProjectKeybyID(int id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_key, project_id FROM projects");

        String key = "";

        while (rs.next()) {
            if (rs.getInt("project_id") == id) {
                key = rs.getString("project_key");
            }
        }

        return key;
    }

    public static void changeOnlineStatus(int u_id, int p_id, int stat) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        st.executeUpdate("UPDATE project_members SET online = '" + stat + "' WHERE project_id = '" + p_id + "' AND user_id = '" + u_id + "'");
        st.close();
    }
    
    public static int getStatus(int u_id, int p_id) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, user_id, online FROM project_members");

        int stat = 0;

        while (rs.next()) {
            if (rs.getInt("user_id") == u_id && rs.getInt("project_id") == p_id) {
                stat = rs.getInt("online");
            }
        }

        return stat;
    }

    public static int getProjectIDbyName(String name) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_id, project_name FROM projects");

        int id = -1;

        while (rs.next()) {
            if (rs.getString("project_name").equals(name)) {
                id = rs.getInt("project_id");
            }
        }

        return id;
    }

    public static int getProjectID(String key) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT project_key, project_id FROM projects");

        int id = -1;

        while (rs.next()) {
            if (rs.getString("project_key").equals(key)) {
                id = rs.getInt("project_id");
            }
        }

        return id;
    }

    public static int getUserID(String name) throws SQLException {
        Connection c = DriverManager.getConnection("jdbc:mariadb://localhost:3325/socket_programming", "root", "root");
        Statement st = c.createStatement();
        ResultSet rs = st.executeQuery("SELECT user_id, name FROM users");

        int id = -1;

        while (rs.next()) {
            if (rs.getString("name").equals(name)) {
                id = rs.getInt("user_id");
            }
        }

        return id;
    }
}
