package socketprogramming;

/**
 *
 * @author samet
 */
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server extends Thread {

    // her clientın bir soketi olamlı
    private ServerSocket serverSocket;
    public boolean isListening = false;
    public int clientId = 0;

    // port numarası
    private int port;

    private ArrayList<SClient> clientList;

    //yapıcı metod
    public Server() {

    }

    // client başlatma
    public boolean Create(int port) {

        try {
            this.port = port;
            // Client Soket nesnesi
            serverSocket = new ServerSocket(this.port);
            clientList = new ArrayList<>();
        } catch (Exception err) {
            System.out.println("Error connecting to server: " + err);
            return false;
        }
        return true;
    }

    @Override
    public void run() {
        try {
            while (this.isListening) {
                if (this.serverSocket != null && !this.serverSocket.isClosed()) {
                    System.out.println("Server waiting client...");
                    try {
                        Socket clientSocket = this.serverSocket.accept(); // blocking
                        SClient nsclient = new SClient(clientSocket, this);
                        nsclient.Listen();
                        clientList.add(nsclient);
                        this.clientId++;
                        String cinfo = JDBC.getNameFromRecent();
                        Chat.lst_clients_model.addElement(cinfo);
                    } catch (IOException e) {
                        if (this.isListening) { // log only if still supposed to be listening
                            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, e);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            if (this.isListening) { // log only if still supposed to be listening
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public void DisconnectClient(SClient client) {
        this.clientList.remove(client);
        Chat.lst_clients_model.removeAllElements();
        for (SClient sClient : clientList) {
            String cinfo = sClient.socket.getInetAddress().toString() + ":" + sClient.socket.getPort();

            Chat.lst_clients_model.addElement(cinfo);
        }

    }
    

    public void Listen() {
        this.isListening = true;
        this.start();
    }

    public void Stop() {
        try {
            this.isListening = false;
            if (this.serverSocket != null && !this.serverSocket.isClosed()) {
                System.out.println("Server is closed!");
                this.serverSocket.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //mesaj gönderme fonksiyonu
    public void SendMessage(byte[] msg, int clientId) {
        msg[msg.length - 1] = 0x14;
        for (SClient sClient : this.clientList) {
            if (clientId == sClient.id) {
                sClient.SendMessage(msg);
                break;
            }
        }

    }

    public void SendBroadCastMessage(byte[] msg) {
        for (SClient sClient : this.clientList) {
            msg[msg.length - 1] = 0x14;
            sClient.SendMessage(msg);
        }
    }

}
